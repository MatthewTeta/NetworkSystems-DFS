#!/bin/bash

ps -aux | grep dfs

